var dateList = [];
function getDayOfYear(a_date) {
	var now = new Date(a_date);
	var start = new Date(now.getFullYear(), 0, 0);
	var diff = now - start;
	var oneDay = 1000 * 60 * 60 * 24;
	var day = Math.floor(diff / oneDay);
	return day;
}

function calcTicketDays(start_day, end_day) {
	var st_day = new Date(start_day);
	var ed_day = new Date(end_day);
	console.log(st_day, ed_day);
	var nextDay = st_day;
	dateList = [];
	while (1) {
		var month = nextDay.getUTCMonth();
		var day = nextDay.getUTCDate();
		var times = (month + 1) * 100 + day;
		dateList.push(times);
		if ((month == ed_day.getUTCMonth()) && (day == ed_day.getUTCDate())) break;
		nextDay.setDate(nextDay.getDate() + 1);
	}
}


startView.addEventListener('click', function () {
	var favEvList = JSON.parse(localStorage.getItem("favEvList"));
	var date = document.getElementById("viewDay").value;
	var today = getDayOfYear(date);

	var infoToday = favEvList[today];
	console.log(infoToday);
	var datalist = [];
	if (infoToday.length > 1) {
		var anHourData;
		for (i = 0; i < 48; i++) {
			anHourData = infoToday[i];
			if (anHourData[0]) {
				datalist.push({ x: i / 2, y: anHourData[0][2] });
			}
		}
	}

	var dailyChart = new CanvasJS.Chart("chartContainer", {
		animationEnabled: true,
		title: {
			text: " Daily Primary Ticket Count"
		},
		axisX: {
			valueFormatString: "##.#h",
			crosshair: {
				enabled: true,
				snapToDataPoint: true
			}
		},
		axisY: {
			title: "Closing Tickets Count",
			includeZero: false,
			valueFormatString: "##0.00",
			crosshair: {
				enabled: true,
				snapToDataPoint: true,
				labelFormatter: function (e) {
					return "$" + CanvasJS.formatNumber(e.value, "##0.00");
				}
			}
		},
		data: [{
			type: "area",
			xValueFormatString: "DD MMM",
			yValueFormatString: "$##0.00",
			dataPoints: datalist
		}]
	});
	dailyChart.render();
});

window.onload = function () {
	var now = new Date();
	var day = ("0" + now.getDate()).slice(-2);
	var month = ("0" + (now.getMonth() + 1)).slice(-2);
	var today1 = now.getFullYear() + "-" + (month) + "-" + (day);
	jQuery('#viewDay').val(today1);

	var favEvList = JSON.parse(localStorage.getItem("favEvList"));
	var date = new Date();
	var today = getDayOfYear(date);

	var infoToday = favEvList[today];
	var datalist = [];
	if (infoToday.length > 1) {
		var anHourData;
		for (i = 0; i < 48; i++) {
			anHourData = infoToday[i];
			if (anHourData[0]) {
				datalist.push({ x: i, y: anHourData[0][2] });
			}
		}
	}
	// daily chart room
	var dailyChart = new CanvasJS.Chart("chartContainer", {
		animationEnabled: true,
		title: {
			text: "Daily Primary Ticket Count"
		},
		axisX: {
			valueFormatString: "*",
			crosshair: {
				enabled: true,
				snapToDataPoint: true
			}
		},
		axisY: {
			title: "Closing Tickets Count",
			includeZero: false,
			valueFormatString: "$##0.00",
			crosshair: {
				enabled: true,
				snapToDataPoint: true,
				labelFormatter: function (e) {
					return "$" + CanvasJS.formatNumber(e.value, "##0.00");
				}
			}
		},
		data: [{
			type: "area",
			xValueFormatString: "DD MMM",
			yValueFormatString: "##0.00",
			dataPoints: datalist
		}]
	});
	dailyChart.render();

	var firstDay = (today - 30) > 0 ? (today - 30) : 0;
	var priorDate = new Date().setDate(date.getDate() - 30);
	calcTicketDays(priorDate, date);
	var monthly = [];
	for (var k = firstDay; k < today; k++) {
		var info = favEvList[k];
		if (info.length > 1) {
			var averge = 0; var count = 0;
			for (i = 0; i < 48; i++) {
				var anHourData = info[i];
				if (anHourData[0]) {
					count++;
					averge += anHourData[0][2];
				}
			}
			if (count == 0) {
				monthly.push({ x: dateList[k - firstDay], y: 0 });
			} else {
				monthly.push({ x: dateList[k - firstDay], y: averge / count });
			}
		} else {
			monthly.push({ x: dateList[k - firstDay], y: 0 });
		}
	}
	console.log(monthly);
	// monthly chart room (last 30 days)
	var dailyChart1 = new CanvasJS.Chart("chartContainer1", {
		animationEnabled: true,
		title: {
			text: "Last 30 days Ticket Checks"
		},
		axisX: {
			valueFormatString: "####",
			crosshair: {
				enabled: true,
				snapToDataPoint: true
			}
		},
		axisY: {
			title: "Closing Tickets Count",
			includeZero: false,
			valueFormatString: "###.00",
			crosshair: {
				enabled: true,
				snapToDataPoint: true,
				labelFormatter: function (e) {
					return "$" + CanvasJS.formatNumber(e.value, "##0.00");
				}
			}
		},
		data: [{
			type: "area",
			xValueFormatString: "##.##",
			yValueFormatString: "$##0.00",
			dataPoints: monthly
		}]
	});
	dailyChart1.render();
}